package com.example.avocado

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
