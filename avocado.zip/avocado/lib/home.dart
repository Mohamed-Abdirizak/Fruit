import 'package:avocado/components/xogtaQudaartaIyoCartiga.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'package:sizer/sizer.dart';

import 'cartpage.dart';
import 'components/qudaarta.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          Navigator.push(context, MaterialPageRoute(builder: (context) {
            return cartPage();
          }));
        },
        backgroundColor: Colors.black,
        child: Icon(
          Icons.shopping_bag,
        ),
      ),
      body: SafeArea(
        child: Padding(
          padding: EdgeInsets.only(top: 6.h),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Padding(
                padding: EdgeInsets.symmetric(horizontal: 24),
                child: Text(
                  "Subax Wanaagsan",
                  style: TextStyle(
                    fontSize: 15.sp,
                  ),
                ),
              ),
              SizedBox(
                height: 2.h,
              ),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 26),
                child: Text(
                  "Dalbo Qudaar fresh ah, helna Vitamin kugu filan!",
                  style: GoogleFonts.notoSerif(
                    fontSize: 20.sp,
                  ),
                ),
              ),
              SizedBox(
                height: 4.h,
              ),
              Divider(
                thickness: 4,
              ),
              SizedBox(
                height: 4.h,
              ),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 24),
                child: Text(
                  "Qudaar Fresh ah",
                  style: GoogleFonts.notoSerif(fontSize: 20.sp),
                ),
              ),
              Expanded(child: Consumer<xogtaQudaartaIyoCartiga>(
                builder: (context, value, child) {
                  return GridView.builder(
                      itemCount: value.shopItem.length,
                      padding: EdgeInsets.only(
                          top: 2.h, left: 2.w, right: 2.w, bottom: 2.h),
                      gridDelegate:
                          const SliverGridDelegateWithFixedCrossAxisCount(
                        crossAxisCount: 2,
                        childAspectRatio: 1 / 1.3,
                      ),
                      itemBuilder: ((context, index) {
                        return QudaartaItemTile(
                          itemName: value.shopItem[index][0],
                          itemPrice: value.shopItem[index][1],
                          imagePath: value.shopItem[index][2],
                          color: value.shopItem[index][3],
                          onPressed: () {
                            Provider.of<xogtaQudaartaIyoCartiga>(context,
                                    listen: false)
                                .addItemstoCart(index);
                          },
                        );
                      }));
                },
              ))
            ],
          ),
        ),
      ),
    );
  }
}
