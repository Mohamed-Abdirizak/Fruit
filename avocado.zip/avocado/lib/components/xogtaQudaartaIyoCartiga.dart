import 'package:flutter/material.dart';

class xogtaQudaartaIyoCartiga extends ChangeNotifier {
  final List _shopItems = [
    ["Avocado", '4.00', "lib/images/avocado.png", Colors.green],
    ["Banana", "2.99", "lib/images/banana.png", Colors.yellow],
    ["Chicken", "12.88", "lib/images/chicken.png", Colors.brown],
    ["Water", "1.88", "lib/images/water.png", Colors.blue]
  ];
  get shopItem => _shopItems;

  List _cartItems = [];
  get cartItesm => _cartItems;

  // add items to cart
  void addItemstoCart(int index) {
    _cartItems.add(_shopItems[index]);
    notifyListeners();
  }

  // remove items to cart
  void removeItemsToCart(int index) {
    _cartItems.removeAt(index);
    notifyListeners();
  }

  /////////// calclulate total prices
  String calcualteTotal() {
    double totalPrice = 0;
    for (int i = 0; i < _cartItems.length; i++) {
      totalPrice += double.parse(_cartItems[i][1]);
    }
    return totalPrice.toStringAsFixed(2);
  }
}
