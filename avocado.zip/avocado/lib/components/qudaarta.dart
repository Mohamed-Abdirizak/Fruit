import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

class QudaartaItemTile extends StatelessWidget {
  final String itemName;
  final String itemPrice;
  final String imagePath;
  final color;
  void Function()? onPressed;

  QudaartaItemTile(
      {super.key,
      required this.itemName,
      required this.itemPrice,
      required this.imagePath,
      required this.color,
      required this.onPressed});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding:
          EdgeInsets.only(top: 1.2.h, bottom: 1.2.h, right: 1.2.w, left: 1.2.w),
      child: Container(
        // padding: EdgeInsets.all(20),
        decoration: BoxDecoration(
            color: color[100], borderRadius: BorderRadius.circular(12)),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: [
            Image.asset(
              imagePath,
              height: 11.4.h,
              // color: color[100],
            ),
            Text(
              itemName,
              style: TextStyle(fontSize: 15.sp),
            ),
            MaterialButton(
              onPressed: onPressed,
              color: color[800],
              child: Text(
                '\$' + itemPrice,
                style: TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                    fontSize: 10.sp),
              ),
            )
          ],
        ),
      ),
    );
  }
}
