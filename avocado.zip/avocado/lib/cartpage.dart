import 'package:avocado/components/xogtaQudaartaIyoCartiga.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:sizer/sizer.dart';

class cartPage extends StatelessWidget {
  const cartPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("My Cart")),
      body: Consumer<xogtaQudaartaIyoCartiga>(
        builder: (context, value, child) {
          return Column(
            children: [
              Expanded(
                  child: ListView.builder(
                      itemCount: value.cartItesm.length,
                      padding: EdgeInsets.only(
                          top: 1.2.h, bottom: 1.2.h, left: 1.2.w, right: 1.2.w),
                      itemBuilder: (context, index) {
                        return Padding(
                          padding: EdgeInsets.only(
                              top: 1.2.h,
                              bottom: 1.2.h,
                              left: 1.2.w,
                              right: 1.2.w),
                          child: Container(
                            decoration: BoxDecoration(
                                color: Colors.grey[200],
                                borderRadius: BorderRadius.circular(12)),
                            child: ListTile(
                                leading: Image.asset(
                                  value.cartItesm[index][2],
                                  height: 5.h,
                                ),
                                title: Text(value.cartItesm[index][0]),
                                subtitle:
                                    Text('\$' + value.cartItesm[index][1]),
                                trailing: IconButton(
                                  icon: Icon(Icons.cancel),
                                  onPressed: () =>
                                      Provider.of<xogtaQudaartaIyoCartiga>(
                                              context,
                                              listen: false)
                                          .removeItemsToCart(index),
                                )
                                // subtitle: Text(value.cartItesm[index][1]),
                                ),
                          ),
                        );
                      })),
              Padding(
                padding: EdgeInsets.only(
                    top: 3.6.h, bottom: 3.6.h, left: 3.6.w, right: 3.6.w),
                child: Container(
                  decoration: BoxDecoration(
                      color: Colors.green,
                      borderRadius: BorderRadius.circular(12)),
                  padding: EdgeInsets.only(
                      top: 2.4.h, bottom: 2.4.h, left: 2.4.w, right: 2.4.w),
                  child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              "Total Price",
                              style: TextStyle(
                                  fontSize: 15.sp, color: Colors.grey[400]),
                            ),
                            Text(
                              "\$" + value.calcualteTotal(),
                              style: TextStyle(
                                  color: Colors.white, fontSize: 20.sp),
                            ),
                          ],
                        ),
                        Container(
                          padding: EdgeInsets.only(
                              top: 1.1.h, bottom: 1.1.h, left: 4.w, right: 4.w),
                          decoration: BoxDecoration(
                              color: Colors.grey[200],
                              borderRadius: BorderRadius.circular(12)),
                          child: Row(children: [
                            Text(
                              "Buy Now",
                              style: TextStyle(fontSize: 10.sp),
                            ),
                            // Icon(Icons.)
                          ]),
                        )
                      ]),
                ),
              )
            ],
          );
        },
      ),
    );
  }
}
