import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:sizer/sizer.dart';

import 'home.dart';

class SplashScreen extends StatelessWidget {
  const SplashScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        children: [
          Center(
            child: Image.asset(
              "lib/images/avocado.png",
              // fit: BoxFit.cover,
              height: 60.h,
              width: 70.w,
            ),
          ),
          SizedBox(
            height: 1.h,
          ),
          Container(
            padding: EdgeInsets.only(left: 6.w, right: 4.w),
            child: Text(
              "Waxaan kuu diyaarine qudaar Vitamins leh",
              style: GoogleFonts.notoSerif(
                  fontSize: 20.sp, fontWeight: FontWeight.bold),
            ),
          ),
          SizedBox(
            height: 4.h,
          ),
          Container(
            padding: EdgeInsets.only(left: 4.w, right: 2.w),
            child: Text(
              "Sifudud ku dalbo adigoo jooga gurigaaga",
              style: TextStyle(fontSize: 12.sp),
            ),
          ),
          SizedBox(
            height: 8.h,
          ),
          GestureDetector(
            onTap: () {
              Navigator.pushReplacement(
                context,
                MaterialPageRoute(
                  builder: (context) => HomeScreen(),
                ),
              );
            },
            child: Container(
              padding: EdgeInsets.only(
                  top: 3.h, left: 10.w, right: 10.w, bottom: 3.h),
              decoration: BoxDecoration(
                color: Colors.blueAccent,
                borderRadius: BorderRadius.circular(20),
              ),
              child: Text(
                "Get Started",
                style: TextStyle(fontSize: 10.sp, color: Colors.white),
              ),
            ),
          )
        ],
      ),
    );
  }
}
