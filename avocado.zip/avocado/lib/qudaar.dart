import 'package:flutter/material.dart';

class qudaarta extends StatelessWidget {
  const qudaarta({super.key});

  @override
  Widget build(BuildContext context) {
    return const Placeholder();
  }
}
